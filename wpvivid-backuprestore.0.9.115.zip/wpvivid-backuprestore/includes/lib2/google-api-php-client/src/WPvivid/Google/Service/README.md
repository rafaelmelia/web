# Google API Client Services

Google API Client Service classes have been moved to the 
[google-api-php-client-services](https://github.com/google/google-api-php-client-services) 
repository. 
